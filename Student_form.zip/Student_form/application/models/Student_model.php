<?php
    class Student_model extends CI_Model{

        public function storeData($data){

            $this->load->database();

            $this->db->insert(" student",$data);

        }
        public function showData(){
            $this->load->database();

            $query=$this->db->get('student');

            $data= $query->result_array();

            return $data;
        }
        public function deleteData($id){
            $this->load->database();

            $this->db->where('id',$id);

            $this->db->delete('student');
        }
        public function getData($id){
            $this->load->database();

            $query=$this->db->get_where('student',array('ID'=>$id));

            $data= $query->row_array();

            return $data;
        }
        public function updateData($data){
            $this->load->database();

            $this->db->where('ID',$data['ID']);

            $this->db->update('student',$data);
;

        }
    }
?>