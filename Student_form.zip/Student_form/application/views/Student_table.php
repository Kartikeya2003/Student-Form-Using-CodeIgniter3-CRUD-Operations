<!--  Table that Show the List     -->


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="wIDth=device-wIDth, initial-scale=1.0">
    <title>Student Records</title>
    <link rel="stylesheet" href=<?php echo base_url().'/vendor/style.css'?>>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.jqueryui.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/scroller/2.1.1/css/scroller.jqueryui.min.css">
</head>                                                   
<body>
    <h1>Student List</h1>                                                              
    <!-- <?php print_r($students) ?> -->                                                     
                                                                                                            
    <table class='table' >                                                
        <thead>          
            <th>Name</th>
            <th>Age</th>                                                     
            <th>Gender</th>
            <th>Email</th>
            <th>Edit</th>
        </thead>

        <?php foreach ($students as $student):?>
            <tr>
                <td><?php echo $student['s_name']?></td>
                <td><?php echo $student['s_age']?></td>
                <td><?php echo $student['s_gender']?></td>
                <td><?php echo $student['s_email']?></td>
                <td> 
                    <a href="<?php echo base_url('index.php/student/getData/'.$student['ID']) ?>">
                    <button>Update</button></a>
                    <a href="<?php echo base_url('index.php/student/deleteData/'.$student['ID']) ?>">
                    <button class="delete" >Delete</button>
                    </a>
                </td>

            </tr>
            <?php endforeach?>
    </table>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.jqueryui.min.js"></script>
    <script src="https://cdn.datatables.net/scroller/2.1.1/js/dataTables.scroller.min.js"></script>
    
    <script>
            $(document).ready(function() {
            $('.table').DataTable();
            });
    </script>



    <a  href="<?php echo base_url().'index.php/student' ?>">
    Add Student Data</a>
            
            
</body>
</html>