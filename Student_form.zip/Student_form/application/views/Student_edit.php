<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Data</title>
    <link rel="stylesheet" href=<?php echo base_url().'/vendor/style.css'?>>
</head>
<body>
<h1>Student Form</h1>
    <br><br>
    <!-- <?php print_r($student);?> -->
    <form name="studentForm" method="POST" action="<?php echo base_url().'index.php/student/updateData'?>">
        <input type="hidden" name="id" value=<?php echo $student['ID']?>>
        Name<input type="text" name="s_name" value=<?php echo $student['s_name']  ?>>
        <br><br>
        Age<input type="number" name="s_age" value=<?php echo $student['s_age'] ?>>
        <br><br>
        Gender<select name="s_gender" >
            <option <?php if ($student['s_gender']=='Male') {echo "Male";} ?>>Male</option>
            <option <?php if ($student['s_gender']=='Female') {echo "Female";} ?>>Female</option>
            </select>
            <br><br>
            Email<input type="email" name="s_email" value=<?php echo $student['s_email'] ?>><span id="errorEmail"></span>
            <br><br>
            <button type="submit">Submit</button>

    </form>
    <a href="<?php echo base_url().'index.php/student/showData'?>">
    Show Data
    </a>
    
</body>
</html>