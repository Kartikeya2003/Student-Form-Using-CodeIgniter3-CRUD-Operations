<?php

    class Student extends CI_Controller{
        

        public function index(){

            $this->load->view("Student_form");
        }
        public function storeData(){
            $data= array(
                    's_name'=>$_POST['s_name'],
                    's_age' => $_POST['s_age'],
                    's_gender	' => $_POST['s_gender'],
                    's_email' => $_POST['s_email']
           );

           $this->Student_model->storeData($data);

           redirect('/student');
        }
        public function showData(){
            
            $data['students']=$this->Student_model->showData();
            
            $this->load->view("Student_table",$data);


        }
        public function deleteData(){
            
            $id=$this->uri->segment(3);
            
            $this->Student_model->deleteData($id);
            
            redirect("/student/showData");
        }
        public function getData(){
            $id=$this->uri->segment(3);
            
            $this->Student_model->getData($id);

            $data['student']=$this->Student_model->getData($id);
            
            $this->load->view('Student_edit',$data);
        }
        public function updateData(){
            $data= array(
                'ID'=>$_POST['id'],
                's_name'=>$_POST['s_name'],
                's_age' => $_POST['s_age'],
                's_gender' => $_POST['s_gender']
                
            );

            $this->Student_model->updateData($data);

            redirect('/student');

        }


    } 

?>